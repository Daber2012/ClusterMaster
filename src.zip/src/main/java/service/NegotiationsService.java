/**
 * Created by Volodymir on 22.09.14.
 */

package main.java.service;

public interface NegotiationsService {

    public void negotiationChecker ();

}