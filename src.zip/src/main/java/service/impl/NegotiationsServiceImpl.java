package main.java.service.impl;

/**
 * Created by Volodymir on 22.09.14.
 */

import main.java.service.NegotiationsService;
import main.java.service.ServerNegotiation;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.*;

public class NegotiationsServiceImpl implements NegotiationsService {

    static class ServiceEntry {
        String ip;
        boolean prim;
        boolean onProc;

        public ServiceEntry (String ip, boolean prim, boolean onProc) {
            this.ip = ip;
            this.prim = prim;
            this.onProc = onProc;
        }
    }


    public volatile boolean active = true;

    private volatile List<ServiceEntry> serversIpes = new ArrayList<ServiceEntry>();

    NegotiationsServiceImpl() {
        sender.run();
        receiver.run();
    }

    private void send(byte msg[]) {
        try {
            MulticastSocket socket = new MulticastSocket();

            socket.setTimeToLive(ServerNegotiation.DEFAULT_PACKET_TTL);

            DatagramPacket pack = new DatagramPacket(msg, msg.length,
                    InetAddress.getByName(ServerNegotiation.DEFAULT_GROUP), ServerNegotiation.DEFAULT_PORT);

            socket.send(pack);

            socket.close();
        } catch(IOException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void negotiationChecker() {
        send(new byte[]{ServerNegotiation.STATUS_REQUEST});
    }

    Runnable sender = new Runnable() {
        @Override
        public void run() {
            while (active) {
                try {
                    Thread.sleep(50 * 1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (!serversIpes.isEmpty()){
                    int count = 0;

                    for (ServiceEntry se : serversIpes) {
                        if (se.prim && !se.onProc) {
                            count++;
                        }
                    }
                    if (count > 1)
                        log("There are some conflict");
                    serversIpes.clear();
                }
                negotiationChecker();
            }
        }
    };

    private boolean isTrue(byte id) {
        if (id == 1) {
            return true;
        } return false;
    }

    Runnable receiver = new Runnable() {
        @Override
        public void run() {
            while (active) {
                try {
                    MulticastSocket socket = new MulticastSocket(ServerNegotiation.DEFAULT_PORT);
                    InetAddress address = InetAddress.getByName(ServerNegotiation.DEFAULT_GROUP);
                    socket.joinGroup(address);

                    byte[] buf = new byte[3];

                    while(active) {
                        DatagramPacket packet = new DatagramPacket(buf, buf.length);
                        socket.receive(packet);

                        //log(packet.getAddress().getHostAddress() + ": " + buf[0] + ":" + buf[1]);

                        if (buf[0] == 3) {
                            log("Server " + packet.getAddress().getHostAddress() + " is ");
                            log(isTrue(buf[1]) ? " primary" : "not primary ");
                            log(isTrue(buf[2]) ? " and on process" : " finally");
                        }

                        serversIpes.add(new ServiceEntry(packet.getAddress().getHostAddress(), isTrue(buf[1]), isTrue(buf[2])));
                    }

                    socket.leaveGroup(address);
                    socket.close();
                } catch (IOException ex) {
                ex.printStackTrace();
                }
            }
        }
    };

    protected void log(String msg) {
        System.out.println(new Date() + ": " + msg);
    }

    public static void main (String args[]) {
        new NegotiationsServiceImpl();
    }
}